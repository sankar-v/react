https://books.google.co.in/books?id=FkBPDwAAQBAJ&pg=PA72&lpg=PA72&dq=snapkite-stream-client&source=bl&ots=WUi-YKfrIQ&sig=ACfU3U0OfOuLhkvvCj6yNq1wGXafQa6wPA&hl=en&sa=X&ved=2ahUKEwiXjY269PHgAhXZh3AKHUTMDccQ6AEwBHoECAIQAQ#v=onepage&q=snapkite-stream-client&f=false

https://github.com/PacktPublishing/React-16-Essentials-Second-Edition