# Has Mobile Photo

Validate if tweet has mobile photo.

Use together with [Snapkite Engine](https://github.com/fedosejev/snapkite-engine).

## Install

1. Copy `example.config.json` into `config.json`.
2. Edit `config.json` as appropriate.

## License

This Snapkite Filter is released under the MIT license.

This software comes with NO WARRANTY, expressed or implied.
