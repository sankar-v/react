# Filters

Install your Snapkite filters in this directory.

[Available filters](https://github.com/Snapkite/snapkite-filters/blob/master/README.md)

## How to install
1. Clone filter repository into this directory.
2. Add filter name to config.json file, into `application.filters` array.
3. Create `config.json` for each filter with appropriate configuration options.
