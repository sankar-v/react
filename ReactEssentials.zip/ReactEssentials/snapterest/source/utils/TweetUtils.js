function getListOfTweetIds(tweets){
    return Object.keys(tweets);
}

module.export.getListOfTweetIds = getListOfTweetIds;